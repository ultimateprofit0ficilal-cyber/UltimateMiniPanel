#!/data/data/com.termux/files/usr/bin/bash
set -e

# One-command APK builder for Termux. Uses the existing Android SDK if available.
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

if ! command -v java >/dev/null 2>&1; then
  echo "Java পাওয়া যায়নি। আগে Termux-এ openjdk ইনস্টল করতে হবে: pkg install openjdk-17 -y"
  exit 1
fi

SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/android-sdk}}"
if [ ! -d "$SDK" ]; then
  echo "Android SDK পাওয়া যায়নি: $SDK"
  echo "এই স্ক্রিপ্টটি বিদ্যমান SDK ব্যবহার করে; SDK ইনস্টল না থাকলে আগে সেটি লাগবে।"
  exit 1
fi
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"

if [ ! -d "$SDK/platforms/android-35" ]; then
  echo "Android SDK Platform 35 পাওয়া যায়নি: $SDK/platforms/android-35"
  echo "SDK Manager দিয়ে platform 35 ইনস্টল করে আবার চালান।"
  exit 1
fi

GRADLE_VERSION="8.7"
GRADLE_HOME_LOCAL="$HOME/.cache/ultimate-minipanel/gradle-$GRADLE_VERSION"
GRADLE_BIN="$GRADLE_HOME_LOCAL/bin/gradle"
if [ ! -x "$GRADLE_BIN" ]; then
  mkdir -p "$HOME/.cache/ultimate-minipanel"
  ARCHIVE="$HOME/.cache/ultimate-minipanel/gradle-$GRADLE_VERSION-bin.zip"
  echo "Gradle $GRADLE_VERSION ডাউনলোড করা হচ্ছে..."
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$ARCHIVE"
  else
    echo "curl পাওয়া যায়নি। আগে pkg install curl -y চালান।"
    exit 1
  fi
  unzip -q -o "$ARCHIVE" -d "$HOME/.cache/ultimate-minipanel"
fi

if [ ! -x "$GRADLE_BIN" ]; then
  # The distribution normally unpacks into this directory.
  GRADLE_BIN="$HOME/.cache/ultimate-minipanel/gradle-$GRADLE_VERSION/bin/gradle"
fi
if [ ! -x "$GRADLE_BIN" ]; then
  echo "Gradle ইনস্টলেশন পাওয়া যায়নি। ZIP extract হয়েছে কি না দেখুন: $HOME/.cache/ultimate-minipanel"
  exit 1
fi

echo "APK build শুরু হচ্ছে..."
"$GRADLE_BIN" --no-daemon assembleDebug
APK="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  cp "$APK" "$PROJECT_DIR/UltimateMiniPanel.apk"
  echo "সফল! APK: $PROJECT_DIR/UltimateMiniPanel.apk"
else
  echo "Build শেষ হয়েছে, কিন্তু APK পাওয়া যায়নি: $APK"
  exit 1
fi
