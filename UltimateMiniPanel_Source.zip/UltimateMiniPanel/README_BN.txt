Ultimate Mini Panel — Android project source

Website: https://ultimateprofite.site/hack/index.php

What it does:
- Opens the supplied website in a draggable Android overlay window.
- Requests Android's Display over other apps permission.
- Has reload and close controls.
- Uses Android WebView cookies and JavaScript for website compatibility.

Important:
- This is Android source code, not a built APK yet.
- Build with Android SDK platform 35 and Android Gradle Plugin 8.6.1 / Gradle 8.7.
- The first run must be started from the app, then grant Display over other apps permission.
- Some Android versions may stop a background overlay; a production version should use a foreground service notification and be tested on the target phone.
- The website's login credentials and PHP security remain the website owner's responsibility. Do not rely on hard-coded demo credentials for production.
