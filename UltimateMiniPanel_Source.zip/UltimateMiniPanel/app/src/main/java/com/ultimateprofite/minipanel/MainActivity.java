package com.ultimateprofite.minipanel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 541;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(0xFFF3F6FB);
        TextView title = new TextView(this);
        title.setText("Ultimate Mini Panel"); title.setTextSize(24); title.setTextColor(0xFF172033); title.setGravity(Gravity.CENTER);
        TextView info = new TextView(this);
        info.setText("অ্যাডমিন প্যানেলটি ভাসমান ছোট উইন্ডোতে চালাতে অনুমতি দিন।"); info.setTextSize(16); info.setTextColor(0xFF596579); info.setGravity(Gravity.CENTER); info.setPadding(0, 18, 0, 24);
        Button start = new Button(this); start.setText("মিনি স্ক্রিন চালু করুন");
        start.setOnClickListener(v -> startFloating());
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
    private void startFloating() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, OVERLAY_REQUEST);
            return;
        }
        startService(new Intent(this, FloatingService.class));
        moveTaskToBack(true);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) startFloating();
    }
}
