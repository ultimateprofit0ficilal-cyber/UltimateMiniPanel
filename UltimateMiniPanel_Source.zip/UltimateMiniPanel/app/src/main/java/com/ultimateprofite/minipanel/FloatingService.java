package com.ultimateprofite.minipanel;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private WebView web;
    private float downX, downY;
    private int startX, startY;
    private static final String URL = "https://ultimateprofite.site/hack/index.php";

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() { super.onCreate(); showPanel(); }
    private void showPanel() {
        if (panel != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(330), dp(500), type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START; params.x = dp(12); params.y = dp(80);

        LinearLayout outer = new LinearLayout(this); outer.setOrientation(LinearLayout.VERTICAL); outer.setBackgroundColor(Color.WHITE); outer.setElevation(dp(10));
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8), 0, dp(4), 0); bar.setBackgroundColor(Color.rgb(89,105,239));
        TextView label = new TextView(this); label.setText("Ultimate Mini Panel"); label.setTextColor(Color.WHITE); label.setTextSize(13); label.setSingleLine(true);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(0, dp(42), 1); bar.addView(label, labelLp);
        Button reload = new Button(this); reload.setText("↻"); reload.setTextSize(17); bar.addView(reload, new LinearLayout.LayoutParams(dp(44), dp(42)));
        Button close = new Button(this); close.setText("×"); close.setTextSize(20); bar.addView(close, new LinearLayout.LayoutParams(dp(44), dp(42)));
        web = new WebView(this); web.setBackgroundColor(Color.WHITE);
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setSupportZoom(true); s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false); s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); web.loadUrl(URL);
        outer.addView(bar, new LinearLayout.LayoutParams(-1, dp(42))); outer.addView(web, new LinearLayout.LayoutParams(-1, 0, 1)); panel = outer;
        View.OnTouchListener drag = (v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; return true; }
            if (e.getAction() == MotionEvent.ACTION_MOVE) { params.x=startX+(int)(e.getRawX()-downX); params.y=startY+(int)(e.getRawY()-downY); try { wm.updateViewLayout(panel, params); } catch(Exception ignored) {} return true; }
            return e.getAction() == MotionEvent.ACTION_UP;
        };
        bar.setOnTouchListener(drag); label.setOnTouchListener(drag);
        reload.setOnClickListener(v -> web.reload()); close.setOnClickListener(v -> stopSelf());
        try { wm.addView(panel, params); } catch (Exception e) { stopSelf(); }
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onDestroy() { if (web != null) { web.stopLoading(); web.destroy(); } if (panel != null && wm != null) { try { wm.removeView(panel); } catch(Exception ignored) {} } panel=null; super.onDestroy(); }
}
